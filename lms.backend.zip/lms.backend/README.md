# ⚙️ LMS Backend (Spring Boot)

This is the core engine of the Learning Management System, providing secure APIs for course management, student progress tracking, and media handling.

---

## 🚀 Technical Highlights

- **Local Storage System**: Automatically manages file uploads to the `uploads/` directory with unique UUID naming.
- **JWT Security**: State-of-the-art stateless authentication with role-based endpoint protection.
- **Data Integrity**: MySQL-backed persistence with Spring Data JPA.
- **API Documentation**: Interactive Swagger UI at `/swagger-ui/index.html`.

---

## 📋 API Reference

### 🔐 Authentication
- `POST /api/auth/signup`: Create a new account.
- `POST /api/auth/login`: Authenticate and receive a JWT.
- `POST /api/auth/validate`: Verify token validity.

### 🛡 Admin (Role: ROLE_ADMIN)
- `GET /api/admin/users`: List all users.
- `PUT /api/admin/users/{id}/role`: Change user permissions.
- `GET /api/admin/courses`: View all courses (including pending).
- `PUT /api/admin/courses/{id}/approve`: Approve/Reject a course.

### 🎓 Instructor (Role: ROLE_INSTRUCTOR)
- `POST /api/instructor/courses`: Create a course.
- `GET /api/instructor/courses`: View your courses.
- `POST /api/instructor/courses/{courseId}/lessons`: Add a lesson.
- `GET /api/instructor/courses/{courseId}/enrollments`: Analytics on enrolled students.

### 🧑‍🎓 Student (Role: ROLE_STUDENT)
- `GET /api/student/courses`: Browse the catalog.
- `POST /api/student/courses/{courseId}/enroll`: Enroll in a course.
- `GET /api/student/enrollments`: View your learning journey.
- `PUT /api/student/progress/{lessonId}`: Mark lesson as complete.
- `GET /api/student/certificates`: Access earned certificates.

### 📝 Quizzes
- `GET /api/quizzes/lesson/{lessonId}`: Fetch quiz for a lesson.
- `POST /api/quizzes/submit`: Submit answers and get instant scores.

---

## 📁 Storage Configuration

The system uses **Local Storage** by default.
- **Upload Directory**: Created automatically at the root of `lms.backend`.
- **Naming Strategy**: Files are renamed to `UUID_originalName` to prevent collisions.
- **Base URL**: Files are served from `http://localhost:8080/uploads/`.

To switch to S3, uncomment the code in `S3Config.java` and provide AWS credentials in `application.properties`.

---

## 🛠 Development Commands

```bash
# Run tests
./mvnw test

# Clean and build
./mvnw clean install

# Run locally
./mvnw spring-boot:run
```
